<?php
require 'php/config.php';
echo "✅ ডেটাবেস সংযোগ সফল হয়েছে!";
?>